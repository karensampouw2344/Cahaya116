package repository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

	private Connection connection;

	public UserRepository() {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cahaya116", "root", "password");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public boolean registerUser(String userId, String username, String email, String password, String gender, String role) {
		String query = "INSERT INTO users (UserID, Username, Email, Password, Gender, Role) VALUES (?, ?, ?, ?, ?, ?)";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, userId);
			stmt.setString(2, username);
			stmt.setString(3, email);
			stmt.setString(4, password);
			stmt.setString(5, gender);
			stmt.setString(6, role);
			int rowsInserted = stmt.executeUpdate();
			return rowsInserted > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean isUsernameUnique(String username) {
		String query = "SELECT COUNT(*) FROM users WHERE Username = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) == 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean isEmailUnique(String email) {
		String query = "SELECT COUNT(*) FROM users WHERE Email = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, email);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) == 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public String generateUserId() {
		String query = "SELECT COUNT(*) FROM users";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
			if (rs.next()) {
				int count = rs.getInt(1) + 1;
				return String.format("US%03d", count);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "US001";
	}

	public boolean validateLogin(String username, String password) {
		String query = "SELECT COUNT(*) FROM users WHERE Username = ? AND Password = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			stmt.setString(2, password);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<String> getUserRoles(String username) {
		List<String> roles = new ArrayList<>();
		String query = "SELECT Role FROM users WHERE Username = ?";
		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					roles.add(rs.getString("Role"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return roles;
	}
}
