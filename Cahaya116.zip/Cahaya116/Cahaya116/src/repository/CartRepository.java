package repository;

import util.Connect;  
import model.Cart;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartRepository {

    private static final String GET_CART_ITEMS_QUERY = "SELECT * FROM cart WHERE UserID = ?";
    private static final String ADD_TO_CART_QUERY = "INSERT INTO cart (UserID, MenuID, Quantity) VALUES (?, ?, ?)";
    private static final String DELETE_CART_ITEM_QUERY = "DELETE FROM cart WHERE UserID = ? AND MenuID = ?";

    public CartRepository() {
        // Default constructor
    }

    // Fetch items from the cart based on the UserID
    public List<Cart> getCartItems(String userId) {
        List<Cart> cartItems = new ArrayList<>();  // Use CartItemData for the list type
        String query = GET_CART_ITEMS_QUERY;

        try (Connection conn = Connect.getInstance().con;
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    @SuppressWarnings("unused")
					String menuId = rs.getString("MenuID");
                    @SuppressWarnings("unused")
					int quantity = rs.getInt("Quantity"); // Now using quantity
                    
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching cart items: " + e.getMessage());
            e.printStackTrace();
        }

        return cartItems;
    }

    // Add a menu item to the cart
    public boolean addToCart(String userId, String menuId, int quantity) {
        String query = ADD_TO_CART_QUERY;
        return executeUpdate(userId, menuId, quantity, query);
    }

    // Delete an item from the cart
    public boolean deleteCartItem(String userId, String menuId) {
        String query = DELETE_CART_ITEM_QUERY;
        return executeUpdate(userId, menuId, 0, query); // No quantity needed for delete
    }

    // Helper method to execute update operations for adding or deleting from the cart
    @SuppressWarnings("unused")
	private boolean executeUpdate(String userId, String menuId, int quantity, String query) {
        try (Connection conn = Connect.getInstance().con;
             PreparedStatement stmt = conn.prepareStatement(query)) {

            if (conn == null) {
                throw new SQLException("Database connection is null.");
            }

            stmt.setString(1, userId);
            stmt.setString(2, menuId);
            if (quantity > 0) {  // Only set quantity for add operation
                stmt.setInt(3, quantity);
            }

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error executing update: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}
