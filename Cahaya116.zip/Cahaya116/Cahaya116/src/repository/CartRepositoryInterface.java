package repository;

import java.util.List;

import model.Cart;

public interface CartRepositoryInterface {
    void addToCart(int userId, int menuId, int quantity);

    void updateCart(int userId, int menuId, int quantity);

    void removeFromCart(int userId, int menuId);

    List<Cart> getCartItems(int userId);

    void clearCart(int userId);

    boolean isItemInCart(int userId, int menuId);

    double getCartTotal(int userId);

    int getCartUniqueItemCount(int userId);

    void applyDiscount(int userId, double discountPercentage);

    void applyDiscountToItem(int userId, int menuId, double discountPercentage);

    boolean isCartPaid(int userId);

    String checkout(int userId);
}
