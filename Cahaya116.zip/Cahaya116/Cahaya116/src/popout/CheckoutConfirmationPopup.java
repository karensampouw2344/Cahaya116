package popout;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CheckoutConfirmationPopup extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Main Application Window
        Button checkoutButton = new Button("Checkout");
        checkoutButton.setOnAction(e -> showConfirmationPopup(primaryStage));

        VBox mainLayout = new VBox(10, checkoutButton);
        mainLayout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Scene mainScene = new Scene(mainLayout, 300, 200);
        primaryStage.setTitle("Cart Page");
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    private void showConfirmationPopup(Stage ownerStage) {
        // Create a new Stage for the pop-up
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL); // Block interaction with other windows
        popupStage.initOwner(ownerStage);
        popupStage.setTitle("Checkout Confirmation");

        // Confirmation message
        Label confirmationLabel = new Label("Are you sure you want to proceed to checkout?");
        confirmationLabel.setStyle("-fx-font-size: 14; -fx-text-fill: black; -fx-alignment: center;"); // Changed text color to black

        // Buttons
        Button yesButton = new Button("Yes");
        yesButton.setOnAction(e -> {
            // Implement checkout logic here
            System.out.println("Proceeding to checkout...");
            popupStage.close(); // Close the pop-up
        });

        Button noButton = new Button("No");
        noButton.setOnAction(e -> popupStage.close()); // Close the pop-up

        // Layout for buttons
        HBox buttonLayout = new HBox(10, yesButton, noButton);
        buttonLayout.setStyle("-fx-alignment: center;");

        // Pop-up layout
        VBox popupLayout = new VBox(20, confirmationLabel, buttonLayout);
        popupLayout.setStyle("-fx-padding: 20; -fx-alignment: center; -fx-background-color: #0078d7;"); // Blue background

        Scene popupScene = new Scene(popupLayout, 350, 150);
        popupStage.setScene(popupScene);
        popupStage.showAndWait(); // Show the pop-up and wait for user action
    }

    public static void main(String[] args) {
        launch(args);
    }
}
