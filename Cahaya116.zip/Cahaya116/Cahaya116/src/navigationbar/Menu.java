package navigationbar;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.MenuItem;

public class Menu extends Application {
	// Observable list for menu data
	private final ObservableList<MenuItem> menuData = FXCollections.observableArrayList();

	// Total Price Label
	private final Label totalPriceLabel = new Label("Total Price: 0");

	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage primaryStage) {
		
		// TableView for Menu
		TableView<MenuItem> menuTable = new TableView<>();
		menuTable.setItems(getMenuData());

		TableColumn<MenuItem, String> nameColumn = new TableColumn<>("Menu Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("menu"));

		TableColumn<MenuItem, Integer> priceColumn = new TableColumn<>("Price");
		priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

		TableColumn<MenuItem, String> descriptionColumn = new TableColumn<>("Description");
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

		menuTable.getColumns().addAll(nameColumn, priceColumn, descriptionColumn);

		// Buttons for Menu operations
		Button addMenuItemButton = new Button("Add Menu Item");
		Button removeMenuItemButton = new Button("Remove Menu Item");

		// Event handlers for the buttons
		addMenuItemButton.setOnAction(e -> addMenuItem());
		removeMenuItemButton.setOnAction(e -> removeMenuItem(menuTable.getSelectionModel().getSelectedItem()));

		// Layout for the UI components
		VBox root = new VBox(menuTable, addMenuItemButton, removeMenuItemButton, totalPriceLabel);
		Scene scene = new Scene(root, 800, 600);

		primaryStage.setTitle("Admin Navigation Bar");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	// Observable list for menu data
	private ObservableList<MenuItem> getMenuData() {
		return FXCollections.observableArrayList(
				new MenuItem("White Rice", 5000, "Steamed white rice"),
				new MenuItem("Red Rice", 7000, "Healthy red rice"),
				new MenuItem("Cheesy Chicken", 10000, "Chicken with melted cheese"),
				new MenuItem("Kungpao Chicken", 15000, "Spicy stir-fried chicken"),
				new MenuItem("Nanban Chicken", 12500, "Japanese-style fried chicken"),
				new MenuItem("Blackpepper Chicken", 17000, "Chicken with black pepper sauce"),
				new MenuItem("Butter Chicken", 18000, "Mild and creamy chicken"),
				new MenuItem("Curry Chicken", 25000, "Chicken in curry sauce"),
				new MenuItem("Salted Egg Chicken", 23000, "Chicken with salted egg sauce"),
				new MenuItem("Perkedel", 8000, "Indonesian fried potato cakes"),
				new MenuItem("Capcay", 7500, "Stir-fried vegetables")
				);
	}

	// Add a new menu item
	private void addMenuItem() {
		// For demonstration, let's add a static item. You can expand this to open a dialog to input item data.
		menuData.add(new MenuItem("New Dish", 10000, "A newly added dish"));
	}

	// Remove a menu item
	private void removeMenuItem(MenuItem selectedItem) {
		if (selectedItem == null) {
			showErrorAlert("No Menu Item Selected", "Please select a menu item to remove.");
			return;
		}

		// Remove the selected item
		menuData.remove(selectedItem);
	}

	// Show Error Alert
	private void showErrorAlert(String title, String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public static void main(String[] args) {
		launch(args);
	}

}

