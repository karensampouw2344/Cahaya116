package navigationbar;
import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class MenuManagementApp extends Application {

	// Observable list for menu items
	private ObservableList<MenuItem> menuItems = FXCollections.observableArrayList();


	@Override
	public void start(Stage primaryStage) {
		// Create components for Menu Management Page
//		Label titleLabel = new Label("Menu Management");

		// Table for displaying menu items
		TableView<MenuItem> tableView = new TableView<>();
		tableView.setItems(menuItems);

		TableColumn<MenuItem, String> nameColumn = new TableColumn<>("Menu Name");
		TableColumn<MenuItem, Double> priceColumn = new TableColumn<>("Price");
		TableColumn<MenuItem, String> descriptionColumn = new TableColumn<>("Description");

		nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
		priceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());
		descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());

		tableView.getColumns().add(nameColumn);
		tableView.getColumns().add(priceColumn);
		tableView.getColumns().add(descriptionColumn);

		// Input fields for new menu item details
		TextField nameInput = new TextField();
		nameInput.setPromptText("Menu Name");

		TextField priceInput = new TextField();
		priceInput.setPromptText("Price");

		TextArea descriptionInput = new TextArea();
		descriptionInput.setPromptText("Menu Description");

		// Buttons for actions
		Button addButton = new Button("Add Menu");
		Button updateButton = new Button("Update Price");
		Button removeButton = new Button("Remove Menu");
		Button checkoutButton = new Button("Checkout");

		// Button actions
		addButton.setOnAction(event -> {
			String name = nameInput.getText();
			String priceText = priceInput.getText();
			String description = descriptionInput.getText();

			if (isValidMenuInput(name, priceText, description)) {
				double price = Double.parseDouble(priceText);
				MenuItem newMenu = new MenuItem(name, price, description);
				menuItems.add(newMenu);
				clearInputs(nameInput, priceInput, descriptionInput);
				showAlert("Success", "Menu added successfully!");
			}
		});

		updateButton.setOnAction(event -> {
			MenuItem selectedItem = tableView.getSelectionModel().getSelectedItem();
			if (selectedItem != null) {
				String newPriceText = priceInput.getText();
				if (isValidPrice(newPriceText)) {
					double newPrice = Double.parseDouble(newPriceText);
					selectedItem.setPrice(newPrice);
					showAlert("Success", "Menu price updated!");
				}
			} else {
				showAlert("Error", "Select a menu to update.");
			}
		});

		removeButton.setOnAction(event -> {
			MenuItem selectedItem = tableView.getSelectionModel().getSelectedItem();
			if (selectedItem != null) {
				menuItems.remove(selectedItem);
				showAlert("Success", "Menu removed!");
			} else {
				showAlert("Error", "Select a menu to remove.");
			}
		});

		checkoutButton.setOnAction(event -> {
			// Show checkout confirmation pop-up
			CheckoutConfirmationPopup.showCheckoutConfirmation();
		});

		// Layout for Menu Management Page
		VBox vbox = new VBox(10);
		vbox.setAlignment(Pos.CENTER);
	//	vbox.getChildren().addAll(titleLabel, tableView, nameInput, priceInput, descriptionInput, addButton, updateButton, removeButton, checkoutButton);

		Scene scene = new Scene(vbox, 500, 500);
		primaryStage.setTitle("Menu Management");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
 // Validate menu 
	private boolean isValidMenuInput(String name, String priceText, String description) {
	    // Check if name is empty or null
	    if (name == null || name.trim().isEmpty()) {
	        showAlert("Error", "Menu Name cannot be empty.");
	        return false;
	    }

	    // Check if description is empty or null
	    if (description == null || description.trim().isEmpty()) {
	        showAlert("Error", "Menu Description cannot be empty.");
	        return false;
	    }

	    // Check if price is a valid number and within the allowed range
	    if (!isValidPrice(priceText)) {
	        return false;
	    }

	    return true;
	}

	// Validate price range
	private boolean isValidPrice(String priceText) {
		try {
			double price = Double.parseDouble(priceText);
			if (price < 5000 || price > 1000000) {
				showAlert("Error", "Price must be between 5000 and 1000000.");
				return false;
			}
		} catch (NumberFormatException e) {
			showAlert("Error", "Invalid price format.");
			return false;
		}
		return true;
	}

	// Show an alert dialog
	private void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	// Clear input fields
	private void clearInputs(TextField nameInput, TextField priceInput, TextArea descriptionInput) {
		nameInput.clear();
		priceInput.clear();
		descriptionInput.clear();
	}

	// MenuItem class representing a menu entry
	class MenuItem {
		private final StringProperty name;
		private final DoubleProperty price;
		private final StringProperty description;

		public MenuItem(String name, double price, String description) {
			this.name = new SimpleStringProperty(name);
			this.price = new SimpleDoubleProperty(price);
			this.description = new SimpleStringProperty(description);
		}

		public String getName() {
			return name.get();
		}

		public StringProperty nameProperty() {
			return name;
		}

		public double getPrice() {
			return price.get();
		}

		public DoubleProperty priceProperty() {
			return price;
		}

		public String getDescription() {
			return description.get();
		}

		public StringProperty descriptionProperty() {
			return description;
		}

		public void setPrice(double price) {
			this.price.set(price);
		}
	}

	// Checkout Confirmation Pop-up (Figure 19)
	class CheckoutConfirmationPopup {

		public static void showCheckoutConfirmation() {
			// Create the alert
			Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			alert.setTitle("Checkout Confirmation");
			alert.setHeaderText("Are you sure you want to checkout?");
			alert.setContentText("If you proceed, your cart will be emptied.");

			// Add Yes and No buttons
			ButtonType yesButton = new ButtonType("Yes");
			ButtonType noButton = new ButtonType("No");
			alert.getButtonTypes().setAll(yesButton, noButton);

			// Handle the response
			alert.showAndWait().ifPresent(response -> {
				if (response == yesButton) {
					// Process the checkout: empty the cart and create a new transaction
					System.out.println("Proceeding with checkout...");
					// Here you would trigger the cart clearing logic
				} else {
					System.out.println("Checkout cancelled.");
				}
			});
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
