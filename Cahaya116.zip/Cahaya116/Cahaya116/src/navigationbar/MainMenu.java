package navigationbar;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainMenu extends Application {
    private Scene scene;
    private BorderPane borderPane;
    private MenuBar menuBar;
    private Menu menu;
    private MenuItem homeItem, cartItem, logoutItem;

    public void initializeComponents() {
        borderPane = new BorderPane();
        menuBar = new MenuBar();
        menu = new Menu("Menu");
        
        homeItem = new MenuItem("Home");
        cartItem = new MenuItem("Cart");
        logoutItem = new MenuItem("Logout");
        
        // Add actions to menu items
        homeItem.setOnAction(e -> System.out.println("Home selected"));
        cartItem.setOnAction(e -> System.out.println("Cart selected"));
        logoutItem.setOnAction(e -> System.out.println("Logout selected"));
    }

    public void initializeMenu() {
        menu.getItems().addAll(homeItem, cartItem, logoutItem);
        menuBar.getMenus().add(menu);
    }

    public void setupStage(Stage primaryStage) {
        borderPane.setTop(menuBar);
        scene = new Scene(borderPane, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Main Menu");
        primaryStage.show();
    }

    @Override
    public void start(Stage primaryStage) {
        initializeComponents();
        initializeMenu();
        setupStage(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}