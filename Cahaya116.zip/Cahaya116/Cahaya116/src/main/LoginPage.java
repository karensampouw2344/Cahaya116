package main;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class LoginPage extends Application {

    // Simulated in-memory database of users and user-roles
    private final Map<String, String> usersDatabase = new HashMap<>();
    private final Map<String, String> userRoles = new HashMap<>();

    @Override
    public void start(Stage stage) {
        // Sample users for testing
        usersDatabase.put("admin", "admin123");
        userRoles.put("admin", "Admin");
        usersDatabase.put("user", "user123");
        userRoles.put("user", "User");

        // Set the stage and show the login scene
        stage.setScene(createLoginScene(stage));
        stage.setTitle("Login Page");
        stage.show();
    }

    public Scene createLoginScene(Stage stage) {
        // Layout
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        // Title
        Label titleLabel = new Label("Login");
        titleLabel.setFont(new Font("Arial", 24)); // Set font size

        // Inputs
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        // Buttons
        Button loginButton = new Button("Login");
        Hyperlink registerLink = new Hyperlink("Don't have an account? Register Here!");

        // Layout arrangement
        gridPane.add(titleLabel, 0, 0, 2, 1); // Title spanning 2 columns
        gridPane.add(usernameLabel, 0, 1);
        gridPane.add(usernameField, 1, 1);
        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(loginButton, 1, 3);
        gridPane.add(registerLink, 1, 4);

        // Center the gridPane within the scene
        StackPane sp = new StackPane(gridPane);
        sp.setAlignment(Pos.CENTER);

        // Event Handling for Login Button
        loginButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            // Validation checks
            if (username.isEmpty() || password.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Username and Password cannot be empty.");
                return;
            }

            // Check credentials against usersDatabase
            if (!usersDatabase.containsKey(username) || !usersDatabase.get(username).equals(password)) {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid credentials.");
                return;
            }

            // Redirect based on user role
            String role = userRoles.get(username);
            if ("Admin".equalsIgnoreCase(role)) {
                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome Admin!");
                // Redirect to Admin-specific page or menu management
            } else {
                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome User!");
                // Redirect to User's home page
            }
        });

        // Event Handling for Register Link
        registerLink.setOnAction(e -> {
            RegisterPage registerPage = new RegisterPage();
            stage.setScene(registerPage.createRegisterScene(stage)); // Navigate to Register Page
        });

        return new Scene(sp, 400, 300);
    }

    // Method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null); // Optional: Remove the header
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}