package main;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class RegisterPage extends Application {

	@Override
	public void start(Stage primaryStage) {
		primaryStage.setScene(createRegisterScene(primaryStage));
		primaryStage.setTitle("Register Form");
		primaryStage.show();
	}


	public Scene createRegisterScene(Stage stage) {
		Label titleLabel = new Label("Register");
		titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

		Label usernameLabel = new Label("Username:");
		Label emailLabel = new Label("Email:");
		Label passwordLabel = new Label("Password:");
		Label genderLabel = new Label("Gender:");
		Label dobLabel = new Label("Date of Birth:");

		// Create Input Fields
		TextField usernameField = new TextField();
		usernameField.setPromptText("Username");

		TextField emailField = new TextField();
		emailField.setPromptText("Email");

		PasswordField passwordField = new PasswordField();
		passwordField.setPromptText("Password");

		RadioButton maleButton = new RadioButton("Male");
		RadioButton femaleButton = new RadioButton("Female");
		ToggleGroup genderGroup = new ToggleGroup();
		maleButton.setToggleGroup(genderGroup);
		femaleButton.setToggleGroup(genderGroup);

		DatePicker datePicker = new DatePicker();

		// Create Buttons
		Button registerButton = new Button("Register");
		Hyperlink loginLink = new Hyperlink("Already have an account? Login here.");

		// Arrange Gender Radio Buttons
		HBox genderBox = new HBox(10, maleButton, femaleButton);
		genderBox.setAlignment(Pos.CENTER);

		// Layout
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets(20));
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		gridPane.setAlignment(Pos.CENTER); // Center the grid pane itself

		gridPane.add(titleLabel, 0, 0, 2, 1);
		GridPane.setHalignment(titleLabel, javafx.geometry.HPos.CENTER);

		gridPane.add(usernameLabel, 0, 1);
		gridPane.add(usernameField, 1, 1);

		gridPane.add(emailLabel, 0, 2);
		gridPane.add(emailField, 1, 2);

		gridPane.add(passwordLabel, 0, 3);
		gridPane.add(passwordField, 1, 3);

		gridPane.add(genderLabel, 0, 4);
		gridPane.add(genderBox, 1, 4);

		gridPane.add(dobLabel, 0, 5);
		gridPane.add(datePicker, 1, 5);

		gridPane.add(registerButton, 1, 6);
		gridPane.add(loginLink, 1, 7);
		GridPane.setHalignment(loginLink, javafx.geometry.HPos.CENTER);

		// Center the GridPane
		BorderPane root = new BorderPane();
		root.setCenter(gridPane);

		// Button Actions
		registerButton.setOnAction(e -> {
			String username = usernameField.getText().trim();
			String email = emailField.getText().trim();
			String password = passwordField.getText().trim();
			String gender = maleButton.isSelected() ? "Male" : femaleButton.isSelected() ? "Female" : null;
			String dob = datePicker.getValue() != null ? datePicker.getValue().toString() : null;

			// Simple Validation
			if (username.isEmpty() || email.isEmpty() || password.isEmpty() || gender == null || dob == null) {
				showAlert(Alert.AlertType.ERROR, "Validation Error");
				return;
			}

			// Registration Success
			showAlert(Alert.AlertType.INFORMATION, "Registration Successful");
		});

		loginLink.setOnAction(e -> {
			// Navigate to Login Page
			LoginPage loginPage = new LoginPage();
			stage.setScene(loginPage.createLoginScene(stage));
		});

		return new Scene(root, 500, 500);
	}

	private void showAlert(AlertType alertType, String message) {
		Alert alert = new Alert(alertType);
		alert.setContentText(message);
		alert.setHeaderText(null);
		alert.showAndWait();
	}


	public static void main(String[] args) {
		launch(args);
	}
}