package util;

import java.sql.*;

public class Connect {
    private final String USERNAME = "root"; // Replace with your MySQL username
    private final String PASSWORD = "";    // Replace with your MySQL password
    private final String DATABASE = "cahaya116"; // Your database name
    private final String HOST = "localhost:3306"; // Adjust host and port if necessary
    private final String CONNECTION = String.format("jdbc:mysql://%s/%s", HOST, DATABASE);

    // Store result sets for SELECT queries
    public ResultSet rs;
    // Store metadata for result sets
    public ResultSetMetaData rsm;
    // Connection to the database
    public Connection con;
    // Statement for executing queries
    private Statement st;

    // Singleton instance
    private static Connect connect;

    // Singleton pattern to ensure a single instance
    public static Connect getInstance() {
        if (connect == null) {
            connect = new Connect();
        }
        return connect;
    }

    // Private constructor to initialize the connection
    private Connect() {
        try {
            con = DriverManager.getConnection(CONNECTION, USERNAME, PASSWORD);
            st = con.createStatement();
            System.out.println("Database connection established successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Connection getConnection() {
        return con;
    }

    // Method to execute SELECT queries
    public ResultSet execQuery(String query) {
        try {
            rs = st.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    // Method to execute UPDATE, DELETE, and INSERT queries
    public void execUpdate(String query) {
        try {
            st.executeUpdate(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to prepare SQL statements
    public PreparedStatement prepareStatement(String query) throws SQLException {
        return con.prepareStatement(query);
    }

    // Method to close the connection
    public void close() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}