package model;


// CartItemData class for cart table
public class CartItem {
	
	public CartItem(String itemName, Integer itemQuantity, Integer itemPrice, Integer itemTotal) {
		super();
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.itemPrice = itemPrice;
		this.itemTotal = itemTotal;
	}
	private  String itemName;
    private  Integer itemQuantity;
    private  Integer itemPrice; // Price per unit
    private  Integer itemTotal;
    
    
    public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Integer getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	public Integer getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(Integer itemPrice) {
		this.itemPrice = itemPrice;
	}
	public Integer getItemTotal() {
		return itemTotal;
	}
	public void setItemTotal(Integer itemTotal) {
		this.itemTotal = itemTotal;
	}
	
}

