package model;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Cart extends Application {
    private final ObservableList<CartItem> cartData = FXCollections.observableArrayList();
    private final Label totalPriceLabel = new Label("Total Price: 0");
    private final CheckBox deliveryInsuranceCheckBox = new CheckBox("Use Delivery Insurance (+2000)");

    @SuppressWarnings("unchecked")
	@Override
    public void start(Stage primaryStage) {

        // TableView for Cart
        TableView<CartItem> cartTable = new TableView<>();
        cartTable.setItems(cartData); // Bind the TableView to the cart data

        // Set up the columns with the correct property names
        TableColumn<CartItem, String> cartNameColumn = new TableColumn<>("Item Name");
        cartNameColumn.setCellValueFactory(new PropertyValueFactory<>("itemName"));

        TableColumn<CartItem, Integer> cartQuantityColumn = new TableColumn<>("Quantity");
        cartQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("itemQuantity"));

        TableColumn<CartItem, Integer> cartTotalColumn = new TableColumn<>("Total");
        cartTotalColumn.setCellValueFactory(new PropertyValueFactory<>("itemTotal"));

        cartTable.getColumns().addAll(cartNameColumn, cartQuantityColumn, cartTotalColumn);

        // Buttons
        Button addToCartButton = new Button("Add to Cart");
        Button removeFromCartButton = new Button("Remove from Cart");
        Button checkoutButton = new Button("Checkout");

        addToCartButton.setOnAction(e -> {
            CartItem selectedMenuItem = cartTable.getSelectionModel().getSelectedItem();
            if (selectedMenuItem != null) {
                addToCart(selectedMenuItem);
            } else {
                showAlert("No Menu Selected", "Please select a menu item to add to the cart.", Alert.AlertType.ERROR);
            }
        });

        removeFromCartButton.setOnAction(e -> {
            CartItem selectedCartItem = cartTable.getSelectionModel().getSelectedItem();
            if (selectedCartItem != null) {
                removeFromCart(selectedCartItem);
            } else {
                showAlert("No Cart Item Selected", "Please select a cart item to remove.", Alert.AlertType.ERROR);
            }
        });

        checkoutButton.setOnAction(e -> checkout());

        // Layout
        HBox buttonsBox = new HBox(10, addToCartButton, removeFromCartButton, checkoutButton);
        VBox root = new VBox(cartTable, buttonsBox, deliveryInsuranceCheckBox, totalPriceLabel);
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Cart");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Populate the cart with initial data
        cartData.addAll(getMenuData());
        updateTotalPrice();
    }

    private ObservableList<CartItem> getMenuData() {
        return FXCollections.observableArrayList(
                new CartItem("White Rice", 1, 5000, 5000),
                new CartItem("Cheesy Chicken", 1, 10000, 10000),
                new CartItem("Kungpao Chicken", 2, 15000, 30000),
                new CartItem("Nanban Chicken", 2, 12500, 25000),
                new CartItem("Blackpepper Chicken", 1, 20000, 20000),
                new CartItem("Butter Chicken", 3, 18000, 54000),
                new CartItem("Curry Chicken", 4, 25000, 100000),
                new CartItem("Salted Egg Chicken", 5, 23000, 115000),
                new CartItem("Perkedel", 2, 8000, 16000),
                new CartItem("Capcay", 2, 7500, 15000)
        );
    }

    private void addToCart(CartItem menuItem) {
        for (CartItem cartItem : cartData) {
            if (cartItem.getItemName().equals(menuItem.getItemName())) {
                // Increase quantity of existing item
                cartItem.setItemQuantity(cartItem.getItemQuantity() + 1);
                cartItem.setItemTotal(cartItem.getItemQuantity() * cartItem.getItemPrice());
                updateTotalPrice();
                return;
            }
        }
        // Add new item to the cart
        cartData.add(new CartItem(menuItem.getItemName(), 1, menuItem.getItemPrice(), menuItem.getItemPrice()));
        updateTotalPrice();
    }

    private void removeFromCart(CartItem cartItem) {
        cartData.remove(cartItem);
        updateTotalPrice();
    }

    private void checkout() {
        if (cartData.isEmpty()) {
            showAlert("Cart Empty", "Please add items to the cart before checking out.", Alert.AlertType.ERROR);
        } else {
            int total = calculateTotalPrice();
            showAlert("Checkout", "Your total is: " + total, Alert.AlertType.INFORMATION);
            cartData.clear();
            updateTotalPrice();
        }
    }

    private int calculateTotalPrice() {
        int total = cartData.stream()
                .mapToInt(item -> item.getItemQuantity() * item.getItemPrice()) // Calculate total for each item dynamically
                .sum();
        if (deliveryInsuranceCheckBox.isSelected()) {
            total += 2000; // Add delivery insurance cost
        }
        return total;
    }

    private void updateTotalPrice() {
        totalPriceLabel.setText("Total Price: " + calculateTotalPrice());
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}